﻿using Maas_Bordrosu_Programi.Domain.Employess;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;

namespace Maas_Bordrosu_Programi.Infrastructure;

public record EmployeeRow(string name, string title);

public static class JsonIo
{
    // Burayı değiştirirsen her şey yeni köke taşınır
    private static readonly string ROOT =
        @"C:\Users\asus\source\repos\Maas_Bordrosu_Programi\json";

    public static string OutputRoot => ROOT;
    public static string EmployeesJson => Path.Combine(ROOT, "personel.json");

    public static List<EmployeeRow> ReadEmployees(string? explicitPath = null)
    {
        var baseDir = AppContext.BaseDirectory;
        var candidates = new[]
        {
            explicitPath,
            EmployeesJson,
            Path.Combine(baseDir, "Data", "personel.json"),
            Path.Combine(baseDir, "Veri", "personel.json"),
        }.Where(p => !string.IsNullOrWhiteSpace(p)).Distinct();

        foreach (var path in candidates)
        {
            if (File.Exists(path))
            {
                var json = File.ReadAllText(path, Encoding.UTF8);
                var opts = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                return JsonSerializer.Deserialize<List<EmployeeRow>>(json, opts) ?? new();
            }
        }

        Directory.CreateDirectory(Path.GetDirectoryName(EmployeesJson)!);
        return new List<EmployeeRow>();
    }

    public static void SaveEmployees(IEnumerable<EmployeeRow> employees, string? explicitPath = null)
    {
        var path = explicitPath ?? EmployeesJson;
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        var json = JsonSerializer.Serialize(employees, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(path, json, Encoding.UTF8);
        Console.WriteLine($"Personel listesi güncellendi: {path}");
    }

    public static void WritePayslip(string root, Maas_Bordrosu_Programi.Domain.Models.Payslip s)
    {
        var dir = Path.Combine(root, Safe(s.EmployeeName), DateTime.Now.ToString("yyyyMM"));
        Directory.CreateDirectory(dir);
        var path = Path.Combine(dir, $"{DateTime.Now:yyyyMMdd}_bordro.json");
        var json = JsonSerializer.Serialize(s, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(path, json, Encoding.UTF8);
        Console.WriteLine($"Kaydedildi: {path}");
    }

    public static void WriteDailySummary(string root, IEnumerable<Maas_Bordrosu_Programi.Domain.Models.Payslip> slips)
    {
        var dayDir = Path.Combine(root, $"bordrolar_{DateTime.Now:yyyy-MM-dd}");
        Directory.CreateDirectory(dayDir);
        File.WriteAllText(Path.Combine(dayDir, "tum_bordrolar.json"),
            JsonSerializer.Serialize(slips, new JsonSerializerOptions { WriteIndented = true }), Encoding.UTF8);
        File.WriteAllText(Path.Combine(dayDir, "150_saat_alti.json"),
            JsonSerializer.Serialize(slips.Where(s => s.WorkHours < 150), new JsonSerializerOptions { WriteIndented = true }), Encoding.UTF8);
        Console.WriteLine($"Gün sonu özetleri oluşturuldu: {dayDir}");
    }

    public static void WriteUnderHoursMonthly(string root, IEnumerable<IEmployee> employees, decimal threshold = 10m, string? period = null)
    {
        var periodStr = period ?? DateTime.Now.ToString("yyyy-MM");
        var list = employees.Where(e => e.MonthlyHours < threshold)
                            .Select(e => new { name = e.Name, title = e.Title, monthlyHours = e.MonthlyHours })
                            .OrderBy(x => x.name).ToList();
        var reportDir = Path.Combine(root, "Raporlar");
        Directory.CreateDirectory(reportDir);
        var file = Path.Combine(reportDir, $"aylik_{periodStr}_under_{threshold:0}_saat.json");
        var json = JsonSerializer.Serialize(list, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(file, json, Encoding.UTF8);
    }

    private static string Safe(string s)
    {
        foreach (var c in Path.GetInvalidFileNameChars()) s = s.Replace(c.ToString(), "");
        return s.Trim();
    }
}